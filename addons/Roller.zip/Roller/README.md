Author: Selindrile
Thanks to: Balloon for creating Rolltracker

Version: 1.3
Automatically performs Corsair rolls.

Commands:
Roller On/Start/Go/Enable/On/Engage
Roller Stop/Off/Quit/End/Disable/Disengage

Roller Roll1 <Name of Roll>    	Sets the first roll
Roller Roll2 <Name of Roll>		Sets the second roll

Presets:

Roller TP
Roller Acc
Roller WS
Roller Nuke
Roller Pet
Roller PetNuke